# FastAPI Imports
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

import uvicorn

# SQLAlchemy Imports for Database Models
from sqlalchemy import func
from sqlalchemy.orm import Session

# Firebase Admin Imports for Authentication
import firebase_admin
from firebase_admin import auth

from datetime import datetime

# Pydantic Models
from typing import List, Dict

# Custom Imports (e.g., utilities, helper functions)
from .db_config import (
    Base,
    get_db,
    engine,
)  # Import engine and SessionLocal from config.py
from .models import (
    User,
    Match,
    Event,
    Share,
    Remarks,
    RemarkType,
)  # Assuming these are your SQLAlchemy models
from .schemas import (
    UserOut,
    EventResponse,
    CreateRemark,
    RegisterUser,
    BuyShareRequest,
    SellShareRequest,
    UserProfile,
    UserProfileEdit,
    ChangePasswordRequest,
    EventDetailResponse,
    MatchResponse
)  # Assuming these are your Pydantic schemas
from .helper import fetch_and_store_matches
from .config import add_cors_middleware, start_scheduler
from .firebase import initialize_firebase

spread_value = 2
# Create the tables
Base.metadata.create_all(bind=engine)

app = FastAPI()
add_cors_middleware(app)


@app.on_event("startup")
async def startup_event():
    initialize_firebase()  # Initialize Firebase
    start_scheduler()  # Start scheduling tasks (like scraping)


@app.get("/api/fetch_and_store_matches")
def fetch_and_store_matches_route(db: Session = Depends(get_db)):
    return fetch_and_store_matches(db)


# API to retrieve all matches
@app.get("/matches", response_model=Dict[str, Dict[str, List[MatchResponse]]])
def get_matches(db: Session = Depends(get_db)):
    matches = db.query(Match).all()
    
    grouped_matches = {}
    for match in matches:
        sport = match.sport
        league = match.league
        match_data = MatchResponse.from_orm(match)
        
        if sport not in grouped_matches:
            grouped_matches[sport] = {}
        if league not in grouped_matches[sport]:
            grouped_matches[sport][league] = []
        
        grouped_matches[sport][league].append(match_data.dict())

    return grouped_matches


@app.get("/matches/basketball", response_model=Dict[str, List[MatchResponse]])
def get_basketball_matches(db: Session = Depends(get_db)):
    """
    Get all upcoming basketball matches grouped by league.
    """
    current_time = datetime.utcnow()

    # Fetch all basketball matches with match_time in the future
    basketball_matches = (
        db.query(Match)
        .filter(Match.sport == "basketball", Match.match_time > current_time)
        .order_by(Match.league, Match.match_time)
        .all()
    )

    if not basketball_matches:
        raise HTTPException(
            status_code=404,
            detail="No upcoming basketball matches found"
        )

    # Group matches by league
    matches_by_league = {}
    for match in basketball_matches:
        league = match.league
        match_data = MatchResponse(
            id=match.id,
            sport=match.sport,
            league=match.league,
            team1=match.team1,
            team2=match.team2,
            match_time=match.match_time.isoformat(),
        )
        if league not in matches_by_league:
            matches_by_league[league] = []
        matches_by_league[league].append(match_data)

    return matches_by_league


@app.get("/event/{event_id}")
async def get_event_by_id(event_id: int, db: Session = Depends(get_db)):
    """
    Get detailed information for a specific event by its ID, including buy/sell prices.
    """
    # Fetch the event and associated match
    db_event = db.query(Event).filter(Event.id == event_id).first()
    if not db_event:
        raise HTTPException(status_code=404, detail=f"Event with ID {event_id} not found")

    db_match = db_event.match
    if not db_match:
        raise HTTPException(
            status_code=404, detail=f"Match for event ID {event_id} not found"
        )

    # Calculate yes/no percentages
    total_yes_bets = db_event.total_yes_bets or 0
    total_no_bets = db_event.total_no_bets or 0
    total_bets = total_yes_bets + total_no_bets
    yes_percentage = (total_yes_bets / total_bets) * 100 if total_bets > 0 else 50

    # Add new variation entry
    new_variation = {
        "timestamp": str(func.now()),
        "yes": round(yes_percentage, 2),
        "no": round(100 - yes_percentage, 2),
    }
    db_event.variations.append(new_variation)
    db.commit()

    # Get buy and sell prices for yes/no
    buy_prices = await get_share_price(eventId=event_id, type="buy", db=db)
    sell_prices = await get_share_price(eventId=event_id, type="sell", db=db)

    # Build response
    response_data = EventResponse(
        id=db_event.id,
        match_id=db_event.match_id,
        heading=db_event.heading,
        question=db_event.question,
        type=db_event.type,
        threshold=db_event.threshold or 0.0,
        total_yes_bets=total_yes_bets,
        total_no_bets=total_no_bets,
        yes_percentage=round(yes_percentage, 2),
        buy_sell_index=db_event.buy_sell_index or 0.0,
        buy_yes_price=buy_prices["yes_price"],
        buy_no_price=buy_prices["no_price"],
        sell_yes_price=sell_prices["yes_price"],
        sell_no_price=sell_prices["no_price"],
        variations=db_event.variations,
        match_time=db_match.match_time.isoformat(),
        sport=db_match.sport,
        league=db_match.league,
        team1=db_match.team1,
        team2=db_match.team2,
    )

    return response_data


@app.get("/events/{match_id}", response_model=Dict[str, List[EventResponse]])
async def get_events_by_match_id(match_id: int, db: Session = Depends(get_db)):
    """
    Get all events for a specific match ID, optionally filtered by heading, including buy/sell prices.
    """
    # Fetch events for the given match ID
    query = db.query(Event).filter(Event.match_id == match_id)

    events = query.all()
    if not events:
        raise HTTPException(
            status_code=404,
            detail= f"No events found for match ID {match_id}",
        )

    grouped_events = {}
    for event in events:    
        # Calculate yes/no percentages
        total_yes_bets = event.total_yes_bets or 0
        total_no_bets = event.total_no_bets or 0
        total_bets = total_yes_bets + total_no_bets
        yes_percentage = (total_yes_bets / total_bets) * 100 if total_bets > 0 else 50

        # Get buy and sell prices for yes/no
        buy_prices = await get_share_price(eventId=event.id, type="buy", db=db)
        sell_prices = await get_share_price(eventId=event.id, type="sell", db=db)

        # Construct the EventResponse object
        event_data = EventResponse(
            id=event.id,
            match_id=event.match_id,
            heading=event.heading,
            question=event.question,
            type=event.type,
            threshold=event.threshold or 0.0,
            total_yes_bets=total_yes_bets,
            total_no_bets=total_no_bets,
            yes_percentage=round(yes_percentage, 2),
            buy_sell_index=event.buy_sell_index or 0.0,
            buy_yes_price=buy_prices["yes_price"],
            buy_no_price=buy_prices["no_price"],
            sell_yes_price=sell_prices["yes_price"],
            sell_no_price=sell_prices["no_price"],
            variations=event.variations,
            match_time=event.match.match_time.isoformat(),
            sport=event.match.sport,
            league=event.match.league,
            team1=event.match.team1,
            team2=event.match.team2,
        )

        # Group events by headings
        if event.heading not in grouped_events:
            grouped_events[event.heading] = []
        grouped_events[event.heading].append(event_data.dict())

    return grouped_events


@app.post("/modifyBalance", response_model=dict)
def modify_balance(create_remark: CreateRemark, db: Session = Depends(get_db)):
    # Check if the user exists
    user = db.query(User).filter(User.id == create_remark.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Create the Remark
    new_remark = Remarks(
        user_id=create_remark.user_id,
        type=create_remark.type,
        message=create_remark.message,
    )

    # Update user's balance based on the type (addBalance or subBalance)
    if create_remark.type == RemarkType.addbalance:
        user.sweeps_points += create_remark.amount
    elif create_remark.type == RemarkType.subbalance:
        if user.sweeps_points < create_remark.amount:
            raise HTTPException(
                status_code=400, detail="Insufficient balance to subtract"
            )
        user.sweeps_points -= create_remark.amount

    # Add the new remark and update the user
    db.add(new_remark)
    db.commit()

    # Return response
    return {
        "message": "Remark added successfully",
        "user_id": create_remark.user_id,
        "amount": create_remark.amount,
    }


@app.post("/ban_unban")
def ban_unban_user(user_id: str, message: str, db: Session = Depends(get_db)):
    # Fetch the user from the database
    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.ban = not (user.ban)

    # Create a new remark in the remarks table
    remark = Remarks(
        user_id=user.id,
        type=RemarkType.ban,  # Set the type as 'ban'
        message=message,
    )

    # Add the user ban and the remark to the session
    db.add(remark)
    db.commit()

    return {
        "message": f"User {user_id} has been banned successfully.",
        "user_id": user_id,
        "ban_status": user.ban,
    }


@app.get("/users/", response_model=List[UserOut])  # Define the response model
def get_users(db: Session = Depends(get_db)):
    # Query all users from the database
    users = db.query(User).all()

    # Convert each user to a dictionary using the `as_dict` method
    users_list = [
        {
            key: value
            for key, value in user.as_dict().items()
            if key
            in [
                "id",
                "email",
                "first_name",
                "last_name",
                "mobile_number",
                "country",
                "created_at",
                "sweeps_points",
                "ban",
            ]
        }
        for user in users
    ]

    return JSONResponse(content=users_list)


@app.get("/users/{user_id}")  # Define the route
def get_user_by_id(user_id: str, db: Session = Depends(get_db)):
    # Query the user by ID from the database
    user = db.query(User).filter(User.id == user_id).first()

    # Check if the user exists
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Calculate total bets placed by the user
    bets_placed = db.query(Share).filter(Share.user_id == user_id).count()

    # Prepare the response data
    response_data = {
        "current_balance": user.sweeps_points,  # Assuming sweeps_points holds the current balance
        "bets_placed": bets_placed,  # Calculated from the Bet table
        "first_name": user.first_name,
        "last_name": user.last_name,
        "full_name": f"{user.first_name} {user.last_name}",  # Concatenate first and last name
        "email": user.email,
        "mobile_number": user.mobile_number,
        "address": user.address,
        "city": user.city,
        "state": user.state,
        "zip_postal": user.zip_postal,
        "country": user.country,
        "ban": user.ban,
    }

    return JSONResponse(content=response_data)


@app.post("/register")
async def register(user: RegisterUser, db: Session = Depends(get_db)):
    try:
        # Create a user in Firebase
        user_record = auth.create_user(email=user.email, password=user.password)

        # Save user info in the local database
        db_user = User(
            id=user_record.uid,  # Using Firebase UID as the ID
            email=user.email,
            name=user.name or "",  # Provide default empty string if None
            first_name=user.first_name or "",  # Default empty string if None
            last_name=user.last_name or "",  # Default empty string if None
            mobile_number=user.mobile_number or "",  # Default empty string if None
            address=user.address or "",  # Default empty string if None
            city=user.city or "",  # Default empty string if None
            state=user.state or "",  # Default empty string if None
            zip_postal=user.zip_postal or "",  # Default empty string if None
            country=user.country or "",  # Default empty string if None
            role=user.role or "USER",  # Default role if None
            sweeps_points=1000.0,  # Default starting balance of Sweeps Points
            betting_points=1000.0,  # Default starting balance of Betting Points
            ban=False,  # Default value for ban status
        )

        db.add(db_user)
        db.commit()  # Commit the transaction to save the user
        db.refresh(db_user)  # Refresh to get the updated instance

        return {"message": "User registered successfully", "uid": user_record.uid}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


security = HTTPBearer()


@app.post("/login")
async def login(token: HTTPAuthorizationCredentials = Depends(security)):
    try:
        # Verify the Firebase ID Token
        decoded_token = auth.verify_id_token(token.credentials)
        uid = decoded_token.get("uid")

        # Firebase already checks expiration, so no need to manually check "exp"
        if not uid:
            raise HTTPException(status_code=400, detail="Token does not contain a UID")

        return {"message": "User authenticated", "uid": uid}

    except auth.ExpiredIdTokenError:
        raise HTTPException(status_code=403, detail="Token has expired")
    except auth.InvalidIdTokenError:
        raise HTTPException(status_code=403, detail="Invalid token")
    except Exception as e:
        raise HTTPException(status_code=403, detail=f"Forbidden: {str(e)}")


@app.post("/api/market/buy-share")
async def buy_share(request: BuyShareRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == request.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if request.bet_type not in ["buy", "sell"]:
        raise HTTPException(
            status_code=400, detail="Invalid bet type. Must be 'buy' or 'sell'."
        )
    if request.outcome not in ["yes", "no"]:
        raise HTTPException(
            status_code=400, detail="Invalid outcome. Must be 'yes' or 'no'."
        )

    event = db.query(Event).filter(Event.id == request.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    existing_shares = (
        db.query(Share)
        .filter(Share.user_id == user.id, Share.event_id == request.event_id)
        .all()
    )

    for share in existing_shares:
        if share.outcome != request.outcome:
            raise HTTPException(
                status_code=400,
                detail=f"Conflicting outcome detected. Existing position is {share.outcome}.",
            )

    opposing_shares = [
        share
        for share in existing_shares
        if share.bet_type != request.bet_type and share.amount > 0
    ]
    remaining_shares = request.shareCount
    total_profit_or_loss = 0

    for share in opposing_shares:
        trade_price = request.share_price
        if share.amount >= remaining_shares:
            trade_amount = remaining_shares
            total_profit_or_loss += trade_amount * (
                request.share_price / 100 - share.share_price / 100
            )
            share.amount -= remaining_shares
            remaining_shares = 0
            db.add(share)
            break
        else:
            trade_amount = share.amount
            total_profit_or_loss += trade_amount * (
                request.share_price / 100 - share.share_price / 100
            )
            remaining_shares -= trade_amount
            db.delete(share)

    user.sweeps_points += total_profit_or_loss

    if remaining_shares > 0:
        total_cost = (request.share_price / 100) * remaining_shares
        if user.sweeps_points < total_cost:
            raise HTTPException(
                status_code=400, detail="Insufficient balance for the trade."
            )
        user.sweeps_points -= total_cost

        new_share = Share(
            user_id=user.id,
            event_id=request.event_id,
            amount=remaining_shares,
            bet_type=request.bet_type,
            outcome=request.outcome,
            share_price=request.share_price,
            limit_price=request.limit_price,
        )
        db.add(new_share)

    if request.outcome == "yes":
        if request.bet_type == "buy":
            event.total_yes_bets += request.shareCount
        else:
            event.total_yes_bets -= request.shareCount
    elif request.outcome == "no":
        if request.bet_type == "buy":
            event.total_no_bets += request.shareCount
        else:
            event.total_no_bets -= request.shareCount

    db.commit()
    return {
        "message": "Trade executed successfully",
        "profit_or_loss": round(total_profit_or_loss, 2),
    }


@app.post("/api/market/sell-share")
async def sell_share(request: SellShareRequest, db: Session = Depends(get_db)):
    # Fetch user
    user = db.query(User).filter(User.id == request.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Validate bet_type and outcome
    if request.bet_type != "sell":
        raise HTTPException(
            status_code=400, detail="Invalid bet type for selling. Must be 'sell'."
        )
    if request.outcome not in ["yes", "no"]:
        raise HTTPException(
            status_code=400, detail="Invalid outcome. Must be 'yes' or 'no'."
        )

    # Fetch event
    event = db.query(Event).filter(Event.id == request.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    # Fetch existing shares for the event
    existing_shares = (
        db.query(Share)
        .filter(Share.user_id == user.id, Share.event_id == request.event_id)
        .all()
    )

    # Check for conflicting outcomes
    for share in existing_shares:
        if share.outcome != request.outcome:
            raise HTTPException(
                status_code=400,
                detail=f"Conflicting outcome detected. Existing position is {share.outcome}.",
            )

    # Resolve opposing positions (e.g., buy existing sell positions)
    opposing_shares = [
        share
        for share in existing_shares
        if share.bet_type == "buy" and share.amount > 0
    ]
    remaining_shares = request.shareCount
    total_profit_or_loss = 0  # Track profit/loss for opposing trades

    for share in opposing_shares:
        trade_price = (
            request.share_price
        )  # Use the current share price for profit/loss calculation
        if share.amount >= remaining_shares:
            # Close partially or fully opposing position
            trade_amount = remaining_shares
            total_profit_or_loss += trade_amount * (
                share.share_price / 100 - request.share_price / 100
            )
            share.amount -= remaining_shares
            remaining_shares = 0
            db.add(share)
            break
        else:
            # Fully close the opposing position
            trade_amount = share.amount
            total_profit_or_loss += trade_amount * (
                share.share_price / 100 - request.share_price / 100
            )
            remaining_shares -= trade_amount
            db.delete(share)

    # Update user's balance based on profit/loss from opposing trades
    user.sweeps_points += total_profit_or_loss

    # Handle remaining shares (opening or updating position)
    if remaining_shares > 0:
        # Deduct cost for new sell position
        total_cost = (request.share_price / 100) * remaining_shares
        if user.sweeps_points < total_cost:
            raise HTTPException(
                status_code=400, detail="Insufficient balance for the trade."
            )
        user.sweeps_points -= total_cost

        # Create a new sell position
        new_share = Share(
            user_id=user.id,
            event_id=request.event_id,
            amount=remaining_shares,
            bet_type="sell",
            outcome=request.outcome,
            share_price=request.share_price,
            limit_price=request.limit_price,
        )
        db.add(new_share)

    # Update event totals
    if request.outcome == "yes":
        event.total_yes_bets -= request.shareCount
    elif request.outcome == "no":
        event.total_no_bets -= request.shareCount

    # Commit transaction
    db.commit()
    return {
        "message": "Trade executed successfully",
        "profit_or_loss": round(total_profit_or_loss, 2),
    }


@app.get("/api/market/share-price")
async def get_share_price(eventId: int, type: str, db: Session = Depends(get_db)):
    # Validate the type parameter
    if type not in ["buy", "sell"]:
        raise HTTPException(
            status_code=400, detail="Invalid type. Must be 'buy' or 'sell'."
        )

    # Retrieve the match details for the given event ID
    match = db.query(Event).filter(Event.id == eventId).first()
    if not match:
        raise HTTPException(status_code=404, detail="Event not found.")

    # Calculate the total shares bought for both outcomes
    total_shares = match.total_yes_bets + match.total_no_bets

    # Set a fixed spread value
    spread_value = 2  # Fixed spread value

    # Avoid division by zero if there are no shares bought yet
    if total_shares == 0:
        yes_price = 50  # Set a base price of 50 when no shares have been bought
        no_price = 50
    else:
        # Calculate share price as a percentage of total shares bought for each outcome
        yes_price = (match.total_yes_bets / total_shares) * 100
        no_price = (match.total_no_bets / total_shares) * 100

    # Adjust prices based on the type (buy or sell)
    if type == "buy":
        yes_price += spread_value
        no_price += spread_value
    elif type == "sell":
        yes_price -= spread_value
        no_price -= spread_value

    # Ensure prices don't go below 0
    yes_price = max(0, yes_price)
    no_price = max(0, no_price)

    return {
        "eventId": eventId,
        "type": type,
        "yes_price": round(yes_price, 2),
        "no_price": round(no_price, 2),
    }


@app.patch("/api/admin/user-profile/edit/{userId}")
def edit_user_profile(
    userId: str, profile_data: UserProfileEdit, db: Session = Depends(get_db)
):
    # Retrieve the user by ID
    user = db.query(User).filter(User.id == userId).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Update profile fields if provided
    if profile_data.first_name:
        user.first_name = profile_data.first_name
    if profile_data.last_name:
        user.last_name = profile_data.last_name
    # If email is updated, update in Firebase Auth
    if profile_data.email and profile_data.email != user.email:
        try:
            # Update email in Firebase Authentication
            firebase_user = auth.get_user_by_email(user.email)
            auth.update_user(firebase_user.uid, email=profile_data.email)
        except auth.UserNotFoundError:
            raise HTTPException(status_code=404, detail="User not found in Firebase")
        except firebase_admin.exceptions.FirebaseError as e:
            raise HTTPException(
                status_code=400, detail=f"Error updating email in Firebase: {str(e)}"
            )
    if profile_data.email:
        user.email = profile_data.email
    if profile_data.mobile_number:
        user.mobile_number = profile_data.mobile_number
    if profile_data.address:
        user.address = profile_data.address
    if profile_data.city:
        user.city = profile_data.city
    if profile_data.state:
        user.state = profile_data.state
    if profile_data.zip_postal:
        user.zip_postal = profile_data.zip_postal
    if profile_data.country:
        user.country = profile_data.country

    # Adjust balance
    if profile_data.add_balance:
        user.sweeps_points += profile_data.add_balance
    if profile_data.subtract_balance:
        if user.sweeps_points >= profile_data.subtract_balance:
            user.sweeps_points -= profile_data.subtract_balance
        else:
            raise HTTPException(
                status_code=400, detail="Insufficient balance for subtraction"
            )

    # Update ban status if provided
    if profile_data.ban is not None:
        user.ban = profile_data.ban

    # Commit changes to the database
    db.commit()
    db.refresh(user)

    return {"message": "User profile updated successfully", "user_id": user.id}


# Dependency to verify the user using Firebase token
def get_current_user(token: str = Depends(HTTPBearer())):
    try:
        # Verify the Firebase token
        decoded_token = auth.verify_id_token(token.credentials)
        uid = decoded_token["uid"]
        return uid
    except Exception as e:
        raise HTTPException(status_code=401, detail="Unauthorized")


@app.get("/api/user/profile/{user_id}", response_model=UserProfile)
async def get_user_profile(
    user_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    # Ensure the current user is authorized to access the requested profile (e.g., user can only access their own profile)
    if current_user != user_id:
        raise HTTPException(status_code=403, detail="Forbidden")

    # Query the database for the user by their user_id
    user = db.query(User).filter(User.id == user_id).first()

    # If no user found, raise an exception
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Return the user profile as a response
    return user.as_dict()


@app.patch("/api/user/profile/edit/{user_id}", response_model=UserProfileEdit)
async def edit_user_profile(
    user_id: str,
    profile_data: UserProfileEdit,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    # Ensure the current user is authorized to edit their own profile
    if current_user != user_id:
        raise HTTPException(status_code=403, detail="Forbidden")

    # Query the database for the user by their user_id
    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Update profile fields if provided
    if profile_data.first_name:
        user.first_name = profile_data.first_name
    if profile_data.last_name:
        user.last_name = profile_data.last_name
    if profile_data.email:
        user.email = profile_data.email
    if profile_data.mobile_number:
        user.mobile_number = profile_data.mobile_number
    if profile_data.address:
        user.address = profile_data.address
    if profile_data.city:
        user.city = profile_data.city
    if profile_data.state:
        user.state = profile_data.state
    if profile_data.zip_postal:
        user.zip_postal = profile_data.zip_postal
    if profile_data.country:
        user.country = profile_data.country

    # Commit changes to the database
    db.commit()
    db.refresh(user)

    return {"message": "Profile updated successfully", "user": user}


@app.patch("/api/user/profile/{user_id}/password")
async def change_password(
    user_id: str,
    password_data: ChangePasswordRequest,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    # Ensure the current user is authorized to change their own password
    if current_user != user_id:
        raise HTTPException(status_code=403, detail="Forbidden")

    # Query the database for the user by their user_id
    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Update password in Firebase
    try:
        # Fetch user from Firebase by the user's ID
        firebase_user = auth.get_user(user.id)

        # Update the password in Firebase
        auth.update_user(firebase_user.uid, password=password_data.new_password)
    except auth.UserNotFoundError:
        raise HTTPException(status_code=404, detail="User not found in Firebase")
    except firebase_admin.exceptions.FirebaseError as e:
        raise HTTPException(
            status_code=400, detail=f"Error updating password in Firebase: {str(e)}"
        )

    return {"message": "Password updated successfully"}


@app.post("/google_signup")
async def google_signup(
    authorization: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    try:
        # Get the Firebase token from the 'Authorization' header (Bearer token)
        id_token = authorization.credentials
        # Verify the Google ID token
        decoded_token = auth.verify_id_token(id_token)
        uid = decoded_token.get("uid")

        # Get the user's info from Firebase
        user_record = auth.get_user(uid)

        # Get user's data (email, name, etc.)
        email = user_record.email
        full_name = user_record.display_name or ""  # Display name in Firebase
        first_name, last_name = "", ""

        if full_name:
            # Assuming full_name is in "First Last" format
            name_parts = full_name.split(" ", 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ""

        # Check if the user already exists in the local database by email or UID
        existing_user = db.query(User).filter(User.email == email).first()
        if existing_user:
            return {"message": "User already exists", "uid": existing_user.id}

        # Create a new user in the local database if not exists
        db_user = User(
            id=uid,  # Using Firebase UID as the ID
            email=email,
            first_name=first_name,
            last_name=last_name,
            name=full_name,
            role="USER",  # Default role
            sweeps_points=1000.0,
            betting_points=1000.0,
            ban=False,
        )

        # Add user to the local database
        db.add(db_user)
        db.commit()  # Commit the transaction to save the user
        db.refresh(db_user)

        return {"message": "User signed up successfully", "uid": uid}

    except auth.InvalidIdTokenError:
        raise HTTPException(status_code=400, detail="Invalid Google token")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/ai-bets", response_model=list)
def get_ai_bets(db: Session = Depends(get_db)):
    """
    API to fetch bets placed by the AI bot.
    Returns a list of bets with team names, league, bet type, outcome, number of shares, and bet time.
    """

    bot_user_id = "ts0Q2DAo9UVORtL2yKu6b3LPIcH3"  # AI bot user ID
    
    # Query to fetch all bets made by the AI bot
    ai_bets = (
        db.query(Share)
        .join(Event, Share.event_id == Event.id)
        .join(Match, Event.match_id == Match.id)
        .filter(Share.user_id == bot_user_id)
        .all()
    )

    if not ai_bets:
        raise HTTPException(status_code=404, detail="No bets found for the AI bot.")

    # Prepare response
    response = []
    for bet in ai_bets:
        response.append({
            "team1": bet.event.match.team1,
            "team2": bet.event.match.team2,
            "league": bet.event.match.league,
            "bet_type": bet.bet_type,
            "outcome": bet.outcome,
            "number_of_shares": bet.amount,
            "bet_time": bet.created_at.strftime("%Y-%m-%d %H:%M:%S")
        })

    return response


@app.get("/events/results", response_model=List[EventDetailResponse])
def get_event_details(db: Session = Depends(get_db)):
    # Query all events and their associated matches
    events = (
        db.query(Event)
        .join(Match, Match.id == Event.match_id)
        .outerjoin(Share, Share.event_id == Event.id)
        .all()
    )
    
    if not events:
        raise HTTPException(status_code=404, detail="No events found.")

    event_details = []
    for event in events:
        total_bets = db.query(Share).filter(Share.event_id == event.id).count()
        match = db.query(Match).filter(Match.id == event.match_id).first()
        
        if not match:
            continue  # Skip if match information is missing

        event_details.append({
            "question": event.question,
            "team1": match.team1,
            "team2": match.team2,
            "bet_end_time": str(match.bet_end_time),
            "total_bets": total_bets,
            "resolved": event.resolved,
            "winner": event.winner,
        })

    return event_details


from pydantic import BaseModel
from .schemas import EventType
# Define the Pydantic model for the input


def add_team_points_events(match_id: int, team_name: str, db: Session):
    """
    Create over/under events for a team's points in a match.
    """
    thresholds = [80, 90, 100, 110, 120]  # Example thresholds for team points
    events = []

    for threshold in thresholds:
        events.append(Event(
            match_id=match_id,
            type=EventType.OVER_UNDER,
            heading=f"{team_name} Points - Over/Under Indices",
            question=f"Will {team_name} score over {threshold} points?",
            threshold=threshold,
            buy_sell_index=100  # Default buy/sell index
        ))

    db.add_all(events)
    db.commit()
    print(f"Team points events added for {team_name} in match ID {match_id}.")


def add_events_for_match(match_id: int, db: Session):
    """
    Add predefined events for a match.
    """
    match = db.query(Match).filter_by(id=match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found.")

    events = []

    # Match Result Event
    events.append(Event(
        match_id=match.id,
        type=EventType.MATCH_RESULT,
        heading="Match Result - 100 Indices",
        question=f"Who will win: {match.team1} or {match.team2}?",
        buy_sell_index=100  # Default buy/sell index for match result
    ))

    # Over/Under Total Points Events
    thresholds = [150.5, 160.5, 170.5, 180.5, 190.5]  # Over/Under thresholds for total points
    for threshold in thresholds:
        events.append(Event(
            match_id=match.id,
            type=EventType.OVER_UNDER,
            heading="Total Points - Over/Under Indices",
            question=f"Will the total points be over or under {threshold}?",
            threshold=threshold,
            buy_sell_index=100  # Default index
        ))

    db.add_all(events)  # Add match result and total points events
    db.commit()

    # Add team-specific events
    add_team_points_events(match.id, match.team1, db)  # For Team 1
    add_team_points_events(match.id, match.team2, db)  # For Team 2

    print(f"Events added for match ID {match_id}.")

class DummyMatchInput(BaseModel):
    id: int
    date: datetime
    time: str
    league_id: int
    league_name: str
    home_team_id: int
    home_team_name: str
    away_team_id: int
    away_team_name: str
    timestamp: int
    sport: str = "basketball"  # Default to basketball

# API to store dummy matches
@app.post("/store-dummy-matches/")
def store_dummy_matches(matches: List[DummyMatchInput], db: Session = Depends(get_db)):
    """
    Store dummy matches in the database.
    """
    for match_data in matches:
        # Check if the match already exists
        existing_match = db.query(Match).filter_by(id=match_data.id).first()
        if existing_match:
            continue  # Skip if the match already exists

        # Create a new Match object
        new_match = Match(
            id=match_data.id,
            match_time=match_data.date,
            league=match_data.league_name,
            team1=match_data.home_team_name,
            team2=match_data.away_team_name,
            sport=match_data.sport,
        )

        db.add(new_match)
        db.commit()
        add_events_for_match(new_match.id, db)

    return {"message": f"{len(matches)} matches added successfully!"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)


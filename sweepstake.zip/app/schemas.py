from pydantic import BaseModel, EmailStr, constr, root_validator
from typing import List, Optional, Dict
from datetime import datetime
from enum import Enum as PyEnum
from .models import UserRole, RemarkType, EventType


class MatchCreate(BaseModel):
    home_team: str
    away_team: str
    match_time: str
    variations: Optional[List[dict]] = []  # Optional JSON field for variations


# Pydantic model for creating a new user
class UserCreate(BaseModel):
    email: EmailStr
    password: constr(min_length=8)  # Password must be at least 8 characters
    name: Optional[str] = None
    country: Optional[str] = None
    role: UserRole = UserRole.USER  # Default role


# Pydantic model for returning user data
class UserOut(BaseModel):
    id: int
    email: EmailStr
    name: Optional[str]
    country: Optional[str]
    created_at: datetime
    role: UserRole

    class Config:
        orm_mode = True  # Enable ORM mode
        arbitrary_types_allowed = True

class MatchResponse(BaseModel):
    id: int
    team1: str
    team2: str
    league: str
    sport: str
    match_time: datetime  # Updated to string
    bet_start_time: Optional[datetime] = None

    class Config:
        orm_mode = True
        from_attributes=True
        json_encoders = {
            datetime: lambda dt: dt.isoformat()  # Ensures datetime fields are serialized as strings
        }

class EventResponse(BaseModel):
    id: int
    match_id: int
    heading: str
    question: str
    type: EventType
    threshold: float
    total_yes_bets: int
    total_no_bets: int
    yes_percentage: float
    buy_sell_index: float
    buy_yes_price: float
    buy_no_price: float
    sell_yes_price: float
    sell_no_price: float
    variations: list[dict]
    match_time: datetime
    sport: str
    league: str
    team1: str
    team2: str

    class Config:
        orm_mode = True
    id: int
    match_id: int
    question: str
    type: EventType  # Ensure the `type` field aligns with the `Event` model
    threshold: Optional[float] = None
    total_yes_bets: int
    total_no_bets: int
    yes_percentage: float
    buy_sell_index: float
    variations: List[dict]
    match_time: str
    sport: str
    league: str
    team1: str
    team2: str

    class Config:
        orm_mode = True


# CreateRemark model that is used to validate the incoming data
class CreateRemark(BaseModel):
    user_id: str
    amount: float
    message: str
    type: RemarkType


class MatchBetUpdate(BaseModel):
    match_id: int
    bet: int


# Pydantic model for returning match data
class MatchOut(BaseModel):
    id: int
    home_team: str
    away_team: str
    match_time: str
    total_yes_bets: int
    total_no_bets: int

    class Config:
        orm_mode = True  # This tells Pydantic to use ORM objects


class UserLogin(BaseModel):
    email: EmailStr  # Email as EmailStr for validation
    password: str  # Password for login

    class Config:
        orm_mode = True  # To allow conversion to and from ORM models


class ShareOut(BaseModel):
    id: int
    user_id: int
    bet_id: int
    amount: float
    created_at: datetime

    class Config:
        orm_mode = True
        arbitrary_types_allowed = True


class RegisterUser(BaseModel):
    name: Optional[str] = None  # Name is optional in case it's not provided
    email: EmailStr  # Use EmailStr for email validation
    password: str  # Password field
    first_name: Optional[str] = None  # First name, optional
    last_name: Optional[str] = None  # Last name, optional
    mobile_number: Optional[str] = None  # Mobile number, optional
    address: Optional[str] = None  # Address, optional
    city: Optional[str] = None  # City, optional
    state: Optional[str] = None  # State, optional
    zip_postal: Optional[str] = None  # Zip code, optional
    country: Optional[str] = None  # Country, optional
    role: Optional[str] = "USER"  # Default role for new users

    class Config:
        orm_mode = True  # To allow conversion to and from ORM models


class BuyShareRequest(BaseModel):
    user_id: str
    event_id: int
    outcome: str  # "yes" or "no"
    bet_type: str  # "buy" or "sell"
    shareCount: int
    share_price: float  # Current price of the share
    limit_price: Optional[float] = None  # Limit price (optional)


class SellShareRequest(BaseModel):
    user_id: str
    event_id: int
    outcome: str  # "yes" or "no"
    bet_type: str  # "buy" or "sell"
    shareCount: int
    share_price: float  # Current price of the share
    limit_price: Optional[float] = None  # Limit price (optional)


class UserProfile(BaseModel):
    id: str
    email: str
    name: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    mobile_number: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_postal: Optional[str] = None
    country: Optional[str] = None
    role: str
    sweeps_points: float
    betting_points: float
    ban: bool
    created_at: str  # ISO format string for created_at

    @root_validator(pre=True)
    def format_datetime(cls, values):
        if "created_at" in values and isinstance(values["created_at"], datetime):
            values["created_at"] = values[
                "created_at"
            ].isoformat()  # Convert to ISO string format
        return values

    class Config:
        orm_mode = True


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str


# Define the request model for updating profile
class UserProfileEdit(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    mobile_number: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_postal: Optional[str] = None
    country: Optional[str] = None
    add_balance: Optional[float] = None
    subtract_balance: Optional[float] = None
    ban: Optional[bool] = None


class EventDetailResponse(BaseModel):
    question: str
    team1: str
    team2: str
    bet_end_time: str
    total_bets: int
    resolved: bool
    winner: str